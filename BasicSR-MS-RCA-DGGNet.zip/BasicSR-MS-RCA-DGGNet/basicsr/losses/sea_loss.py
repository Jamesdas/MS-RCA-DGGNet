import torch
import torch.nn as nn

class CustomGradientLoss(nn.Module):
    def __init__(self, opt):
        super(CustomGradientLoss, self).__init__()
        # 在这里根据需要接收配置参数，例如学习率、权重等
        self.weight = opt.get('weight', 1.0)

    def forward(self, output, gradient_label):
        # 在这里定义计算梯度损失的逻辑
        # output 是主网络的输出
        # gradient_label 是根据原始图像计算的梯度标签

        # 示例：计算 L1 损失
        l1_loss = torch.nn.functional.l1_loss(output, gradient_label)

        # 使用权重进行加权
        custom_gradient_loss = self.weight * l1_loss

        return custom_gradient_loss
