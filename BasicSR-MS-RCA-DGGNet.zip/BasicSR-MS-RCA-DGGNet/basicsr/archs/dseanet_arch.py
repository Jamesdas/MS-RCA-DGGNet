# import torch
# import torch.nn as nn
# from torch.nn import functional as F
# from basicsr.utils.registry import ARCH_REGISTRY
# import os
# # os.environ["CUDA_VISIBLE_DEVICES"]='0'
#
#
# class ChannelAttention(nn.Module):
#     def __init__(self, in_channels, ratio=16):
#         super(ChannelAttention, self).__init__()
#         self.avg_pool = nn.AdaptiveAvgPool2d(1)
#         self.max_pool = nn.AdaptiveMaxPool2d(1)
#
#         self.fc1 = nn.Conv2d(in_channels, in_channels // ratio, 1, bias=False)
#         self.relu1 = nn.ReLU()
#         self.fc2 = nn.Conv2d(in_channels // ratio, in_channels, 1, bias=False)
#
#         self.sigmoid = nn.Sigmoid()
#
#     def forward(self, x):
#         avg_out = self.fc2(self.relu1(self.fc1(self.avg_pool(x))))
#         max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
#         out = avg_out + max_out
#         return self.sigmoid(out)
#
#
#
# class CAMSRB(nn.Module):
#     def __init__(self, in_channels, out_channels):
#         super(CAMSRB, self).__init__()
#
#         # 3x3 卷积
#         self.conv_3x3 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
#         # 5x5 卷积，为了保持feature map的大小不变，设置padding为2
#         self.conv_5x5 = nn.Conv2d(in_channels, out_channels, kernel_size=5, padding=2)
#
#         # 特征融合的1x1卷积
#         self.fusion_conv = nn.Conv2d(out_channels * 2, out_channels, kernel_size=1, padding=0)
#
#         # 如果输入和输出通道数不一致，添加一个1x1卷积来匹配通道数
#         if in_channels != out_channels:
#             self.match_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1, padding=0)
#         else:
#             self.match_conv = None
#
#         # 激活函数
#         self.relu = nn.ReLU(inplace=True)
#
#         # 通道注意力机制
#         self.ca = ChannelAttention(in_channels)
#
#     def forward(self, x):
#         # 分别通过3x3和5x5卷积层
#         conv_3x3_out = self.relu(self.conv_3x3(x))
#         conv_5x5_out = self.relu(self.conv_5x5(x))
#
#         # 将两个尺度的特征图进行concatenation
#         combined = torch.cat([conv_3x3_out, conv_5x5_out], dim=1)
#
#         # 经过1x1卷积进行特征融合
#         output = self.fusion_conv(combined)
#
#         # 如果存在match_conv，使用它来改变x的通道数
#         if self.match_conv is not None:
#             x = self.match_conv(x)
#
#         # 通过通道注意力机制
#         output = self.ca(output) * output
#
#         # 添加残差连接
#         output = output + x
#
#         return output
# # 定义亚像素卷积上采样模块
# class SubPixelConvUpsample(nn.Module):
#     def __init__(self, in_channels, out_channels, upscale_factor):
#         super(SubPixelConvUpsample, self).__init__()
#         self.conv = nn.Conv2d(in_channels, out_channels * (upscale_factor ** 2), kernel_size=3, padding=1)
#         self.pixel_shuffle = nn.PixelShuffle(upscale_factor)
#         self.conv_final = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
#
#     def forward(self, x):
#         x = self.conv(x)
#         #print("Conv Output Shape:", x.shape)
#         x = self.pixel_shuffle(x)
#         #print("Pixel Shuffle Output Shape:", x.shape)
#         x = self.conv_final(x)
#         #print("Conv Final Output Shape:", x.shape)
#         return x
#
# class DynamicConv2d(nn.Module):
#     def __init__(self, in_channels, out_channels, kernel_size):
#         super(DynamicConv2d, self).__init__()
#         self.in_channels = in_channels
#         self.out_channels = out_channels
#         self.kernel_size = kernel_size
#
#         # 初始化动态卷积的权重
#         self.weight = nn.Parameter(torch.randn(out_channels, in_channels, kernel_size, kernel_size))
#
#     def forward(self, x):
#         # 动态生成卷积核
#         dynamic_weight = F.normalize(self.weight, p=1, dim=0)
#         # 执行动态卷积
#         output = F.conv2d(x, dynamic_weight, stride=1, padding=self.kernel_size // 2)
#         return output
#
# class DynamicConvolutionalLayer(nn.Module):
#     def __init__(self, in_channels, out_channels, kernel_size):
#         super(DynamicConvolutionalLayer, self).__init__()
#         self.dynamic_conv = DynamicConv2d(in_channels, out_channels, kernel_size)
#         self.relu = nn.ReLU(inplace=True)
#
#     def forward(self, x):
#         x = self.dynamic_conv(x)
#         x = self.relu(x)
#         return x
# # 定义梯度模块
# class GradientModule(nn.Module):
#     def __init__(self, in_channels, out_channels):
#         super(GradientModule, self).__init__()
#         self.sobel = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
#
#         # 动态卷积，你可以根据需要调整卷积核的数量和其他参数
#         # self.dynamic_conv1 = DynamicConvolutionalLayer(out_channels, out_channels, kernel_size=3)
#         # self.dynamic_conv2 = DynamicConvolutionalLayer(out_channels, out_channels, kernel_size=3)
#         # self.dynamic_conv3 = DynamicConvolutionalLayer(out_channels, out_channels, kernel_size=3)
#         # self.dynamic_conv4 = DynamicConvolutionalLayer(out_channels, out_channels, kernel_size=3)
#         self.dynamic_conv1 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
#         self.dynamic_conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
#         self.dynamic_conv3 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
#         self.dynamic_conv4 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
#         self.upsample = SubPixelConvUpsample(out_channels, out_channels, upscale_factor=4)
#         self.dynamic_conv5 = nn.Conv2d(out_channels, 1, kernel_size=3, padding=1)
#
#
#
#     def forward(self, x):
#         gradient = self.sobel(x)
#         dynamic_conv1_out = self.dynamic_conv1(gradient)
#         dynamic_conv2_out = self.dynamic_conv2(dynamic_conv1_out)
#         dynamic_conv3_out = self.dynamic_conv3(dynamic_conv2_out)
#         dynamic_conv4_out = self.dynamic_conv4(dynamic_conv3_out)
#         upsampled_gradient = self.dynamic_conv5(self.upsample(dynamic_conv4_out))
#
#
#
#         return dynamic_conv1_out, dynamic_conv2_out, dynamic_conv3_out, dynamic_conv4_out, upsampled_gradient
#
#
#
#
# # 定义主网络
# class MainNetwork(nn.Module):
#     def __init__(self, in_channels, out_channels):
#         super(MainNetwork, self).__init__()
#
#         # 主网络的第一层普通卷积
#         self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
#         self.conv2 = nn.Conv2d(2*out_channels, out_channels, kernel_size=1, padding=0)
#         self.conv3 = nn.Conv2d(2*out_channels, out_channels, kernel_size=1, padding=0)
#         self.conv4 = nn.Conv2d(2*out_channels, out_channels, kernel_size=1, padding=0)
#         self.conv5 = nn.Conv2d(2*out_channels, out_channels, kernel_size=1, padding=0)
#
#         # CAMSRB 模块
#         self.camsrb1 = CAMSRB(out_channels, out_channels)
#         self.camsrb2 = CAMSRB(2*out_channels, 2*out_channels)
#         self.camsrb3 = CAMSRB(2*out_channels, 2*out_channels)
#         self.camsrb4 = CAMSRB(2*out_channels, 2*out_channels)
#
#         # 亚像素卷积上采样模块
#         self.upsample = SubPixelConvUpsample(out_channels, out_channels, upscale_factor=4)
#
#         # PReLU激活层
#         self.prelu = nn.PReLU()
#
#         # 添加一个卷积层用于降低通道数到 3
#         self.reduce_channels = nn.Conv2d(out_channels, 3, kernel_size=1, padding=0)
#
#     def forward(self, x, dynamic_conv1_out, dynamic_conv2_out, dynamic_conv3_out, dynamic_conv4_out):
#         # 主网络的前向传播
#         x = self.conv1(x)
#         #print("Conv1 Output Shape:", x.shape)
#         camsrb1_out = self.camsrb1(x)
#         #print("CAMSRB1 Output Shape:", camsrb1_out.shape)
#         #print("dynamic Output Shape1:", dynamic_conv1_out.shape)
#         #print(out_channels)
#         camsrb2_out = self.camsrb2(torch.cat([camsrb1_out, dynamic_conv1_out], dim=1))
#         #print("CAMSRB2 Output Shape:", camsrb2_out.shape)
#         #print("dynamic Output Shape2:", dynamic_conv2_out.shape)
#         camsrb3_out = self.camsrb3(torch.cat([self.conv2(camsrb2_out), dynamic_conv2_out], dim=1))
#         #print("CAMSRB3 Output Shape:", camsrb3_out.shape)
#         #print("dynamic Output Shape3:", dynamic_conv3_out.shape)
#         camsrb4_out = self.camsrb4(torch.cat([self.conv3(camsrb3_out), dynamic_conv3_out], dim=1))
#         #print("conv3 Shape:", self.conv3(camsrb3_out).shape)
#         #print("CAMSRB4 Output Shape:", camsrb4_out.shape)
#         #print("dynamic Output Shape4:", dynamic_conv4_out.shape)
#
#         # output = self.conv4(camsrb4_out)
#         # print("conv4 Shape:", output.shape)
#
#         # 进行亚像素卷积
#         #output = self.upsample(self.conv3(camsrb4_out))
#         output = torch.cat([self.conv4(camsrb4_out), dynamic_conv4_out], dim=1)
#         #print("Final Output Shape1:", output.shape)
#         output = self.conv4(output)
#         output = self.prelu(output)
#         output = self.upsample(output)
#         #print("Final Output Shape1:", output.shape)
#
#         output = self.reduce_channels(output)  # 降低通道数到 3
#         output = self.prelu(output)
#
#         #print("Final Output Shape2:", output.shape)
#
#         return output
#
# # 定义整体网络
# @ARCH_REGISTRY.register()
# class Dggnet(nn.Module):
#     def __init__(self,
#                  in_channels=3,
#                  out_channels=64,
#                  img_range=255,
#                  rgb_mean=(0.4488, 0.4371, 0.4040),
#                  ):  # 添加 gradient_loss_weight 参数
#         super(Dggnet, self).__init__()
#
#         self.img_range = img_range
#         self.mean = torch.Tensor(rgb_mean).view(1, 3, 1, 1)
#
#         # 梯度分支
#         self.gradient_module = GradientModule(in_channels, out_channels)
#
#         # 主网络分支
#         self.main_network = MainNetwork(in_channels, out_channels)
#
#
#     def forward(self, x):
#         # 获取梯度分支的输出
#         dynamic_conv1_out, dynamic_conv2_out, dynamic_conv3_out, dynamic_conv4_out, upsampled_gradient = self.gradient_module(x)
#
#         # 主网络分支的前向传播
#         main_network_out = self.main_network(x, dynamic_conv1_out, dynamic_conv2_out, dynamic_conv3_out, dynamic_conv4_out)
#
#
#         return main_network_out, upsampled_gradient
#
#         # return main_network_out
#
#
#
# # 测试部分
# if __name__ == "__main__":
#     # 创建 FullNetwork 的实例
#     in_channels = 3  # 输入通道数，这里假设为3，你可以根据实际情况修改
#     out_channels = 64  # 输出通道数，你可以根据实际情况修改
#     full_network = Dggnet(in_channels, out_channels)
#     #full_network.cuda()
#
#     # 定义一个示例输入
#     example_input = torch.randn((1, in_channels, 192, 192))  # 假设输入大小为 (batch_size=1, channels, height, width)
#
#     # 将示例输入传递给网络
#     #output, _ = full_network(example_input)
#     output = full_network(example_input)
#
#     # 仅使用 main_network_out
#     main_network_output = output
#     #print("Main Network Output Shape:", main_network_output.shape)
#     #
#     # # 打印输出张量的形状
#     # print("Output Shape:", output.shape)
#
